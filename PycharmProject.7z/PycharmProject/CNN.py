import numpy as np
from sklearn.datasets import fetch_openml
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelBinarizer
from sklearn.metrics import accuracy_score


# --------------------------------------
# 工具函数
# --------------------------------------
def im2col(images, kernel_height, kernel_width, stride=1, padding=0):
    """将图像块转换为列矩阵以便卷积运算"""
    n_images, in_channels, height, width = images.shape
    padded = np.pad(images, ((0, 0), (0, 0), (padding, padding), (padding, padding)), mode='constant')
    out_height = (height + 2 * padding - kernel_height) // stride + 1
    out_width = (width + 2 * padding - kernel_width) // stride + 1

    cols = np.zeros((n_images * out_height * out_width, in_channels * kernel_height * kernel_width))

    idx = 0
    for i in range(n_images):
        for h in range(out_height):
            for w in range(out_width):
                h_start = h * stride
                h_end = h_start + kernel_height
                w_start = w * stride
                w_end = w_start + kernel_width
                patch = padded[i, :, h_start:h_end, w_start:w_end]
                cols[idx] = patch.flatten()
                idx += 1
    return cols


def col2im(cols, images_shape, kernel_height, kernel_width, stride=1, padding=0):
    """将列矩阵还原为图像"""
    n_images, in_channels, height, width = images_shape
    out_height = (height + 2 * padding - kernel_height) // stride + 1
    out_width = (width + 2 * padding - kernel_width) // stride + 1

    padded = np.zeros((n_images, in_channels, height + 2 * padding, width + 2 * padding))

    idx = 0
    for i in range(n_images):
        for h in range(out_height):
            for w in range(out_width):
                h_start = h * stride
                h_end = h_start + kernel_height
                w_start = w * stride
                w_end = w_start + kernel_width
                col_patch = cols[idx].reshape(in_channels, kernel_height, kernel_width)
                padded[i, :, h_start:h_end, w_start:w_end] += col_patch
                idx += 1

    return padded[:, :, padding:-padding, padding:-padding]


# --------------------------------------
# 层定义
# --------------------------------------
class Conv2D:
    def __init__(self, in_channels, out_channels, kernel_size, stride=1, padding=0):
        self.in_channels = in_channels
        self.out_channels = out_channels
        self.kernel_size = kernel_size
        self.stride = stride
        self.padding = padding

        # Xavier 初始化
        scale = np.sqrt(1. / (in_channels * kernel_size * kernel_size))
        self.weights = np.random.randn(out_channels, in_channels, kernel_size, kernel_size) * scale
        self.bias = np.zeros(out_channels)

    def forward(self, x):
        self.x = x
        n, c, h, w = x.shape
        k = self.kernel_size
        self.x_col = im2col(x, k, k, self.stride, self.padding)
        w_unf = self.weights.reshape(self.out_channels, -1)
        out = (w_unf @ self.x_col.T).T + self.bias
        out_h = (h + 2 * self.padding - k) // self.stride + 1
        out_w = (w + 2 * self.padding - k) // self.stride + 1
        return out.reshape(n, out_h, out_w, self.out_channels).transpose(0, 3, 1, 2)

    def backward(self, dout):
        n, c, h, w = self.x.shape
        k = self.kernel_size
        dout_reshaped = dout.transpose(0, 2, 3, 1).reshape(-1, self.out_channels)

        dW = dout_reshaped.T @ self.x_col
        db = np.sum(dout_reshaped, axis=0)

        dx_cols = self.weights.reshape(self.out_channels, -1).T @ dout_reshaped.T
        dx = col2im(dx_cols, self.x.shape, k, k, self.stride, self.padding)

        self.dW = dW.reshape(self.weights.shape)
        self.db = db
        return dx

    def update(self, lr):
        self.weights -= lr * self.dW
        self.bias -= lr * self.db


class MaxPool2D:
    def __init__(self, kernel_size, stride=None):
        self.kernel_size = kernel_size
        self.stride = stride if stride else kernel_size

    def forward(self, x):
        self.x = x
        n, c, h, w = x.shape
        k = self.kernel_size
        s = self.stride
        out_h = (h - k) // s + 1
        out_w = (w - k) // s + 1
        out = np.zeros((n, c, out_h, out_w))

        self.max_indices = []

        for i in range(n):
            for j in range(c):
                for y in range(out_h):
                    for x_coord in range(out_w):
                        h_start = y * s
                        h_end = h_start + k
                        w_start = x_coord * s
                        w_end = w_start + k
                        patch = x[i, j, h_start:h_end, w_start:w_end]
                        max_val = np.max(patch)
                        max_idx = np.unravel_index(np.argmax(patch), patch.shape)
                        out[i, j, y, x_coord] = max_val
                        self.max_indices.append((i, j, h_start + max_idx[0], w_start + max_idx[1]))
        return out

    def backward(self, dout):
        dx = np.zeros_like(self.x)
        idx = 0
        n, c, out_h, out_w = dout.shape
        s = self.stride
        k = self.kernel_size

        for i in range(n):
            for j in range(c):
                for y in range(out_h):
                    for x_coord in range(out_w):
                        _, _, h_idx, w_idx = self.max_indices[idx]
                        dx[i, j, h_idx, w_idx] = dout[i, j, y, x_coord]
                        idx += 1
        return dx


class ReLU:
    def forward(self, x):
        self.x = x
        return np.maximum(0, x)

    def backward(self, dout):
        return dout * (self.x > 0)


class Linear:
    def __init__(self, in_features, out_features):
        scale = np.sqrt(1. / in_features)
        self.weights = np.random.randn(out_features, in_features) * scale
        self.bias = np.zeros(out_features)

    def forward(self, x):
        self.x = x
        return self.weights @ x + self.bias

    def backward(self, dout):
        self.dW = dout.reshape(-1, 1) @ self.x.reshape(1, -1)
        self.db = dout
        return self.weights.T @ dout

    def update(self, lr):
        self.weights -= lr * self.dW
        self.bias -= lr * self.db


# --------------------------------------
# CNN 模型
# --------------------------------------
class CNN:
    def __init__(self):
        self.conv1 = Conv2D(1, 6, 5, padding=2)
        self.pool1 = MaxPool2D(2)
        self.relu1 = ReLU()
        self.fc1 = Linear(6 * 12 * 12, 128)
        self.relu2 = ReLU()
        self.fc2 = Linear(128, 10)

    def forward(self, x):
        x = self.conv1.forward(x)
        x = self.relu1.forward(x)
        x = self.pool1.forward(x)
        x = x.reshape(x.shape[0], -1)
        x = self.fc1.forward(x)
        x = self.relu2.forward(x)
        x = self.fc2.forward(x)
        return x

    def backward(self, dout):
        dout = self.fc2.backward(dout)
        dout = self.relu2.backward(dout)
        dout = self.fc1.backward(dout)
        dout = dout.reshape(*self.pool1.x.shape)
        dout = self.pool1.backward(dout)
        dout = self.relu1.backward(dout)
        self.conv1.backward(dout)

    def update(self, lr):
        self.conv1.update(lr)
        self.fc1.update(lr)
        self.fc2.update(lr)

    def predict(self, x):
        logits = self.forward(x)
        return np.argmax(logits, axis=1)

    def loss(self, x, y):
        logits = self.forward(x)
        probs = np.exp(logits - np.max(logits, axis=1, keepdims=True))
        probs /= probs.sum(axis=1, keepdims=True)
        loss = -np.mean(np.log(probs[np.arange(len(y)), y] + 1e-15))
        return loss, probs


# --------------------------------------
# 数据加载与训练
# --------------------------------------
if __name__ == "__main__":
    # 加载 MNIST 数据集
    X, y = fetch_openml('mnist_780', version=1, return_X_y=True, parser='auto')
    X = X.astype(np.float32) / 255.
    X = X.values.reshape(-1, 1, 28, 28)
    y = y.astype(int)

    lb = LabelBinarizer()
    y_onehot = lb.fit_transform(y)

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    # 训练模型
    model = CNN()
    batch_size = 128
    epochs = 10
    learning_rate = 0.01

    for epoch in range(epochs):
        indices = np.random.permutation(len(X_train))
        for i in range(0, len(X_train), batch_size):
            batch_indices = indices[i:i+batch_size]
            X_batch, y_batch = X_train[batch_indices], y_train[batch_indices]

            loss, probs = model.loss(X_batch, y_batch)
            dout = probs.copy()
            dout[np.arange(len(y_batch)), y_batch] -= 1
            model.backward(dout)
            model.update(learning_rate)

        # 测试准确率
        y_pred = model.predict(X_test)
        acc = accuracy_score(y_test, y_pred)
        print(f"Epoch {epoch+1}/{epochs}, Loss: {loss:.4f}, Accuracy: {acc:.4f}")