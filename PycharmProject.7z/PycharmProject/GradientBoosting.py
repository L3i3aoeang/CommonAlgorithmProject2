import numpy as np
from sklearn.tree import DecisionTreeRegressor  # 使用sklearn的回归树作为基学习器


class GradientBoostingRegressor:
    def __init__(self, n_estimators=100, learning_rate=0.1, max_depth=3):
        self.n_estimators = n_estimators  # 树的数量
        self.learning_rate = learning_rate  # 学习率
        self.max_depth = max_depth  # 每棵树的最大深度
        self.trees = []
        self.base_pred = None  # 初始预测（均值）

    def _mse_loss(self, y_true, y_pred):
        """均方误差损失函数"""
        return np.mean((y_true - y_pred) ** 2)

    def _negative_gradient(self, y_true, y_pred):
        """计算负梯度（残差）"""
        return y_true - y_pred

    def fit(self, X, y):
        # 初始预测（训练集的均值）
        self.base_pred = np.mean(y)
        y_pred = np.full_like(y, self.base_pred, dtype=np.float64)

        for _ in range(self.n_estimators):
            # 1. 计算负梯度（残差）
            residuals = self._negative_gradient(y, y_pred)

            # 2. 训练新树来拟合残差
            tree = DecisionTreeRegressor(max_depth=self.max_depth)
            tree.fit(X, residuals)

            # 3. 更新预测（学习率衰减）
            y_pred += self.learning_rate * tree.predict(X)

            # 保存树
            self.trees.append(tree)

    def predict(self, X):
        """预测（初始预测 + 所有树的加权输出）"""
        y_pred = np.full(X.shape[0], self.base_pred, dtype=np.float64)
        for tree in self.trees:
            y_pred += self.learning_rate * tree.predict(X)
        return y_pred

from sklearn.datasets import load_boston
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error

# 加载数据（注：新版sklearn移除了boston数据集，可替换为其他数据集）
data = load_boston()
X, y = data.data, data.target
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# 训练GBM模型
model = GradientBoostingRegressor(n_estimators=100, learning_rate=0.1, max_depth=3)
model.fit(X_train, y_train)

# 评估
y_pred = model.predict(X_test)
mse = mean_squared_error(y_test, y_pred)
print(f"测试集MSE: {mse:.2f}")
print(f"自定义GBM预测示例: {y_pred[:5]}")
print(f"真实值: {y_test[:5]}")

# 与Scikit-learn对比
from sklearn.ensemble import GradientBoostingRegressor as SkGBR
sk_model = SkGBR(n_estimators=100, learning_rate=0.1, max_depth=3, random_state=42)
sk_model.fit(X_train, y_train)
print(f"Scikit-learn GBM MSE: {mean_squared_error(y_test, sk_model.predict(X_test)):.2f}")