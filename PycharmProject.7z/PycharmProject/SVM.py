import numpy as np
from sklearn.datasets import make_classification
import matplotlib.pyplot as plt


class SVM:
    def __init__(self, C=1.0, kernel='linear', gamma='auto', tol=1e-3, max_iter=100):
        self.C = C  # 正则化参数
        self.kernel = kernel  # 核函数类型
        self.gamma = gamma  # RBF核参数
        self.tol = tol  # 容忍误差
        self.max_iter = max_iter  # 最大迭代次数
        self.alpha = None  # 拉格朗日乘子
        self.b = 0  # 偏置项
        self.X_sv = None  # 支持向量
        self.y_sv = None  # 支持向量标签

    def _kernel_func(self, x1, x2):
        """核函数计算"""
        if self.kernel == 'linear':
            return np.dot(x1, x2)
        elif self.kernel == 'rbf':
            if self.gamma == 'auto':
                self.gamma = 1.0 / x1.shape[0]
            return np.exp(-self.gamma * np.linalg.norm(x1 - x2) ** 2)
        else:
            raise ValueError("Unsupported kernel type")

    def fit(self, X, y):
        n_samples, n_features = X.shape
        self.alpha = np.zeros(n_samples)
        self.b = 0

        # 计算核矩阵（Gram矩阵）
        K = np.zeros((n_samples, n_samples))
        for i in range(n_samples):
            for j in range(n_samples):
                K[i, j] = self._kernel_func(X[i], X[j])

        # SMO算法简化实现
        iter = 0
        while iter < self.max_iter:
            alpha_prev = np.copy(self.alpha)

            for i in range(n_samples):
                # 计算预测误差
                Ei = np.sum(self.alpha * y * K[:, i]) + self.b - y[i]

                # 违反KKT条件则更新alpha_i和alpha_j
                if (y[i] * Ei < -self.tol and self.alpha[i] < self.C) or \
                        (y[i] * Ei > self.tol and self.alpha[i] > 0):

                    # 随机选择另一个alpha_j
                    j = np.random.choice([x for x in range(n_samples) if x != i])
                    Ej = np.sum(self.alpha * y * K[:, j]) + self.b - y[j]

                    # 保存旧值
                    alpha_i_old, alpha_j_old = self.alpha[i], self.alpha[j]

                    # 计算边界L和H
                    if y[i] != y[j]:
                        L = max(0, self.alpha[j] - self.alpha[i])
                        H = min(self.C, self.C + self.alpha[j] - self.alpha[i])
                    else:
                        L = max(0, self.alpha[i] + self.alpha[j] - self.C)
                        H = min(self.C, self.alpha[i] + self.alpha[j])

                    if L == H:
                        continue

                    # 计算eta
                    eta = 2 * K[i, j] - K[i, i] - K[j, j]
                    if eta >= 0:
                        continue

                    # 更新alpha_j
                    self.alpha[j] -= y[j] * (Ei - Ej) / eta
                    self.alpha[j] = np.clip(self.alpha[j], L, H)

                    # 检查alpha_j变化是否显著
                    if abs(self.alpha[j] - alpha_j_old) < 1e-5:
                        continue

                    # 更新alpha_i
                    self.alpha[i] += y[i] * y[j] * (alpha_j_old - self.alpha[j])

                    # 更新偏置b
                    b1 = self.b - Ei - y[i] * (self.alpha[i] - alpha_i_old) * K[i, i] - \
                         y[j] * (self.alpha[j] - alpha_j_old) * K[i, j]
                    b2 = self.b - Ej - y[i] * (self.alpha[i] - alpha_i_old) * K[i, j] - \
                         y[j] * (self.alpha[j] - alpha_j_old) * K[j, j]

                    if 0 < self.alpha[i] < self.C:
                        self.b = b1
                    elif 0 < self.alpha[j] < self.C:
                        self.b = b2
                    else:
                        self.b = (b1 + b2) / 2

            # 检查收敛
            if np.linalg.norm(self.alpha - alpha_prev) < self.tol:
                break

            iter += 1

        # 保存支持向量
        sv_idx = self.alpha > 1e-5
        self.X_sv = X[sv_idx]
        self.y_sv = y[sv_idx]
        self.alpha_sv = self.alpha[sv_idx]

    def predict(self, X):
        """预测函数"""
        y_pred = np.zeros(X.shape[0])
        for i in range(X.shape[0]):
            s = 0
            for alpha, y_sv, x_sv in zip(self.alpha_sv, self.y_sv, self.X_sv):
                s += alpha * y_sv * self._kernel_func(X[i], x_sv)
            y_pred[i] = s + self.b
        return np.sign(y_pred)

    def decision_function(self, X):
        """返回决策函数值"""
        return self.predict(X)

###可视化决策边界

# 生成线性可分数据
X, y = make_classification(n_samples=100, n_features=2, n_redundant=0,
                           n_clusters_per_class=1, random_state=42)
y = np.where(y == 0, -1, 1)  # 标签转换为-1和1

# 训练SVM
model = SVM(C=1.0, kernel='linear', max_iter=1000)
model.fit(X, y)


# 可视化
def plot_decision_boundary(X, y, model):
    x_min, x_max = X[:, 0].min() - 1, X[:, 0].max() + 1
    y_min, y_max = X[:, 1].min() - 1, X[:, 1].max() + 1
    xx, yy = np.meshgrid(np.linspace(x_min, x_max, 100),
                         np.linspace(y_min, y_max, 100))

    Z = model.predict(np.c_[xx.ravel(), yy.ravel()])
    Z = Z.reshape(xx.shape)

    plt.contourf(xx, yy, Z, alpha=0.4)
    plt.scatter(X[:, 0], X[:, 1], c=y, s=20, edgecolor='k')
    plt.scatter(model.X_sv[:, 0], model.X_sv[:, 1],
                facecolors='none', edgecolors='r', s=100, label='Support Vectors')
    plt.title("SVM Decision Boundary")
    plt.legend()


plot_decision_boundary(X, y, model)
plt.show()