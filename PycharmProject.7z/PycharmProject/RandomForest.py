import numpy as np
from collections import Counter
from decision_tree import DecisionTree  # 引用之前实现的决策树


class RandomForest:
    def __init__(self, n_trees=10, max_depth=10, min_samples_split=2, n_features=None):
        self.n_trees = n_trees
        self.max_depth = max_depth
        self.min_samples_split = min_samples_split
        self.n_features = n_features  # 每棵树考虑的最大特征数
        self.trees = []

    def _bootstrap_sample(self, X, y):
        """生成自助采样集（有放回抽样）"""
        n_samples = X.shape[0]
        idxs = np.random.choice(n_samples, size=n_samples, replace=True)
        return X[idxs], y[idxs]

    def _most_common_label(self, y):
        """投票选出最多类别"""
        return Counter(y).most_common(1)[0][0]

    def fit(self, X, y):
        """训练随机森林"""
        self.trees = []
        n_features = X.shape[1] if not self.n_features else min(self.n_features, X.shape[1])

        for _ in range(self.n_trees):
            # 1. 自助采样
            X_sample, y_sample = self._bootstrap_sample(X, y)

            # 2. 随机选择特征子集（列采样）
            feat_idxs = np.random.choice(X.shape[1], size=n_features, replace=False)

            # 3. 训练决策树
            tree = DecisionTree(
                max_depth=self.max_depth,
                min_samples_split=self.min_samples_split
            )
            tree.fit(X_sample[:, feat_idxs], y_sample)
            self.trees.append((tree, feat_idxs))  # 保存树及其使用的特征索引

    def predict(self, X):
        """预测（多数投票）"""
        tree_preds = np.zeros((len(X), self.n_trees))

        for i, (tree, feat_idxs) in enumerate(self.trees):
            tree_preds[:, i] = tree.predict(X[:, feat_idxs])

        return [self._most_common_label(tree_pred) for tree_pred in tree_preds]


from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score

# 加载数据
iris = load_iris()
X, y = iris.data, iris.target
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# 训练随机森林
model = RandomForest(n_trees=20, max_depth=5, n_features=2)
model.fit(X_train, y_train)

# 评估
y_pred = model.predict(X_test)
print(f"自定义随机森林准确率: {accuracy_score(y_test, y_pred):.2f}")

# 与Scikit-learn对比
from sklearn.ensemble import RandomForestClassifier
sk_model = RandomForestClassifier(n_estimators=20, max_depth=5, max_features=2, random_state=42)
sk_model.fit(X_train, y_train)
print(f"Scikit-learn随机森林准确率: {sk_model.score(X_test, y_test):.2f}")