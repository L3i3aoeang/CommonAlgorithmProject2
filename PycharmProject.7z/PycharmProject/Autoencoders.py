import numpy as np
from sklearn.datasets import fetch_openml
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import MinMaxScaler


# --------------------------------------
# 工具函数
# --------------------------------------
def sigmoid(x):
    return 1 / (1 + np.exp(-x))


def sigmoid_derivative(x):
    return x * (1 - x)


def mse_loss(y_true, y_pred):
    return np.mean((y_true - y_pred) ** 2)


def mse_derivative(y_true, y_pred):
    return 2 * (y_pred - y_true) / y_true.shape[0]


# --------------------------------------
# Autoencoder 模型
# --------------------------------------
class Autoencoder:
    def __init__(self, input_dim, hidden_dim):
        """
        初始化网络参数
        :param input_dim: 输入维度（如 MNIST 为 784）
        :param hidden_dim: 隐藏层维度（bottleneck）
        """
        # Encoder 权重
        self.W1 = np.random.randn(input_dim, hidden_dim) * 0.01
        self.b1 = np.zeros(hidden_dim)

        # Decoder 权重
        self.W2 = np.random.randn(hidden_dim, input_dim) * 0.01
        self.b2 = np.zeros(input_dim)

    def encode(self, x):
        """前向传播 - 编码器部分"""
        self.z1 = x @ self.W1 + self.b1
        self.h = sigmoid(self.z1)  # 潜在空间表示
        return self.h

    def decode(self, h):
        """前向传播 - 解码器部分"""
        self.z2 = h @ self.W2 + self.b2
        self.y_hat = sigmoid(self.z2)  # 输出重构
        return self.y_hat

    def forward(self, x):
        """完整前向传播"""
        self.encode(x)
        return self.decode(self.h)

    def backward(self, x, y, learning_rate=1e-3):
        """反向传播"""
        # 输出层梯度
        d_z2 = mse_derivative(x, y) * sigmoid_derivative(y)
        dW2 = self.h.T @ d_z2
        db2 = np.sum(d_z2, axis=0)

        # 隐藏层梯度
        d_h = d_z2 @ self.W2.T
        d_z1 = d_h * sigmoid_derivative(self.h)
        dW1 = x.T @ d_z1
        db1 = np.sum(d_z1, axis=0)

        # 参数更新
        self.W2 -= learning_rate * dW2
        self.b2 -= learning_rate * db2
        self.W1 -= learning_rate * dW1
        self.b1 -= learning_rate * db1

    def train(self, X_train, epochs=100, batch_size=64, learning_rate=1e-3):
        """训练函数"""
        losses = []
        n_samples = X_train.shape[0]
        for epoch in range(epochs):
            indices = np.random.permutation(n_samples)
            for i in range(0, n_samples, batch_size):
                batch_indices = indices[i:i+batch_size]
                batch = X_train[batch_indices]

                # 前向传播
                output = self.forward(batch)

                # 反向传播
                self.backward(batch, output, learning_rate)

            # 计算损失
            loss = mse_loss(X_train, self.forward(X_train))
            losses.append(loss)
            if (epoch + 1) % 10 == 0:
                print(f"Epoch {epoch+1}/{epochs}, Loss: {loss:.5f}")

        return losses


# --------------------------------------
# 数据预处理
# --------------------------------------
# 加载 MNIST 数据集
X, y = fetch_openml('mnist_780', version=1, return_X_y=True, parser='auto')
X = X / 255.0  # 归一化到 [0, 1]

# 只用一部分数据加快训练速度
X = X[:10000]

# 转换为 numpy 数组
X = X.values.astype(np.float32)

# 划分训练集和测试集
X_train, X_test = train_test_split(X, test_size=0.2, random_state=42)

# 初始化模型
input_dim = 784
hidden_dim = 64  # Bottleneck 维度
autoencoder = Autoencoder(input_dim, hidden_dim)

# 训练模型
losses = autoencoder.train(X_train, epochs=100, batch_size=128, learning_rate=0.01)

# 测试可视化
import matplotlib.pyplot as plt

# 选择一些样本进行重构
n = 5
indices = np.random.choice(len(X_test), size=n)
original = X_test[indices]
reconstructed = autoencoder.forward(original)

# 显示图像
plt.figure(figsize=(20, 4))
for i in range(n):
    # 原始图像
    ax = plt.subplot(2, n, i + 1)
    plt.imshow(original[i].reshape(28, 28), cmap='gray')
    plt.title("Original")
    plt.axis("off")

    # 重构图像
    ax = plt.subplot(2, n, i + 1 + n)
    plt.imshow(reconstructed[i].reshape(28, 28), cmap='gray')
    plt.title("Reconstructed")
    plt.axis("off")
plt.show()