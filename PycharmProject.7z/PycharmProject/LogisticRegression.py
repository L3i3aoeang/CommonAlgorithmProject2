import numpy as np
import matplotlib.pyplot as plt

class LogisticRegression:
    def __init__(self, learning_rate=0.01, n_iters=1000):
        self.lr = learning_rate      # 学习率
        self.n_iters = n_iters        # 迭代次数
        self.weights = None           # 权重
        self.bias = None              # 偏置

    def _sigmoid(self, z):
        """Sigmoid激活函数"""
        return 1 / (1 + np.exp(-z))

    def fit(self, X, y):
        n_samples, n_features = X.shape
        self.weights = np.zeros(n_features)
        self.bias = 0

        # 梯度下降
        for _ in range(self.n_iters):
            # 线性组合 + Sigmoid激活
            linear_model = np.dot(X, self.weights) + self.bias
            y_pred = self._sigmoid(linear_model)

            # 计算梯度（交叉熵损失的导数）
            dw = (1/n_samples) * np.dot(X.T, (y_pred - y))
            db = (1/n_samples) * np.sum(y_pred - y)

            # 更新参数
            self.weights -= self.lr * dw
            self.bias -= self.lr * db

    def predict(self, X, threshold=0.5):
        """预测类别（默认阈值0.5）"""
        linear_model = np.dot(X, self.weights) + self.bias
        y_pred = self._sigmoid(linear_model)
        return (y_pred >= threshold).astype(int)

# 生成模拟数据
np.random.seed(42)
X = np.random.randn(100, 2)
y = np.array([0 if x1 + x2 < 0 else 1 for x1, x2 in X])  # 简单线性决策边界

# 训练模型
model = LogisticRegression(learning_rate=0.1, n_iters=1000)
model.fit(X, y)

# 预测
y_pred = model.predict(X)
accuracy = np.mean(y_pred == y)
print(f"训练准确率: {accuracy:.2f}")