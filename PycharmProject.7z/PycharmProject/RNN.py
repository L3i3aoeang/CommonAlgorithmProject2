import numpy as np
import matplotlib.pyplot as plt


class RNN:
    def __init__(self, input_size, hidden_size, output_size):
        """
        初始化 RNN 参数
        :param input_size: 输入维度（词汇量大小）
        :param hidden_size: 隐藏层维度
        :param output_size: 输出维度（词汇量大小）
        """
        self.input_size = input_size
        self.hidden_size = hidden_size
        self.output_size = output_size

        # Xavier 初始化权重
        scale = np.sqrt(1. / input_size)
        self.Wxh = np.random.randn(hidden_size, input_size) * scale
        self.Whh = np.random.randn(hidden_size, hidden_size) * scale
        self.Why = np.random.randn(output_size, hidden_size) * scale

        self.bh = np.zeros((hidden_size, 1))
        self.by = np.zeros((output_size, 1))

    def forward(self, inputs, h_prev):
        """
        前向传播
        :param inputs: 输入序列，shape: [seq_length]
        :param h_prev: 初始隐藏状态，shape: [hidden_size, 1]
        :return: outputs, hidden_states
        """
        seq_length = len(inputs)
        hidden_states = [h_prev.copy()]
        outputs = []

        for t in range(seq_length):
            x = np.zeros((self.input_size, 1))
            x[inputs[t]] = 1  # one-hot 编码

            h = np.tanh(np.dot(self.Wxh, x) + np.dot(self.Whh, hidden_states[-1]) + self.bh)
            y = np.dot(self.Why, h) + self.by

            hidden_states.append(h)
            outputs.append(y)

        return outputs, hidden_states

    def loss(self, outputs, targets):
        """
        计算交叉熵损失和预测概率
        :param outputs: 网络输出列表，每个元素为 [output_size, 1] 的数组
        :param targets: 目标标签序列，shape: [seq_length]
        :return: 损失值、softmax 概率
        """
        probs = []
        loss = 0.0
        for t in range(len(outputs)):
            prob = np.exp(outputs[t] - np.max(outputs[t]))
            prob /= np.sum(prob)
            loss += -np.log(prob[targets[t], 0] + 1e-15)
            probs.append(prob)
        return loss, probs

    def backward(self, inputs, targets, hidden_states, probs, dh_next=None):
        """
        反向传播
        :param inputs: 输入序列
        :param targets: 目标序列
        :param hidden_states: 所有时间步的隐藏状态
        :param probs: softmax 概率
        :param dh_next: 最后一步的梯度
        :return: 梯度更新项，最后一步的 dh
        """
        dWxh, dWhh, dWhy = np.zeros_like(self.Wxh), np.zeros_like(self.Whh), np.zeros_like(self.Why)
        dbh, dby = np.zeros_like(self.bh), np.zeros_like(self.by)
        dh = dh_next if dh_next is not None else np.zeros_like(hidden_states[0])

        for t in reversed(range(len(inputs))):
            x = np.zeros((self.input_size, 1))
            x[inputs[t]] = 1

            dy = probs[t]
            dy[targets[t]] -= 1  # (output_size, 1)

            dWhy += np.dot(dy, hidden_states[t+1].T)
            dby += dy

            dh = np.dot(self.Why.T, dy) + dh
            dh_raw = (1 - hidden_states[t+1] ** 2) * dh

            dWxh += np.dot(dh_raw, x.T)
            dWhh += np.dot(dh_raw, hidden_states[t].T)
            dbh += dh_raw

            dh = dh_raw

        return dWxh, dWhh, dWhy, dbh, dby, dh

    def update(self, dWxh, dWhh, dWhy, dbh, dby, lr=1e-3):
        """参数更新"""
        self.Wxh -= lr * dWxh
        self.Whh -= lr * dWhh
        self.Why -= lr * dWhy
        self.bh -= lr * dbh
        self.by -= lr * dby

    def sample(self, seed_ix, n):
        """
        根据当前模型生成一段文本
        :param seed_ix: 起始字符索引
        :param n: 要生成的字符数
        :return: 字符索引列表
        """
        h = np.zeros((self.hidden_size, 1))
        x = np.zeros((self.input_size, 1))
        x[seed_ix] = 1
        ixes = [seed_ix]

        for t in range(n):
            h = np.tanh(np.dot(self.Wxh, x) + np.dot(self.Whh, h) + self.bh)
            y = np.dot(self.Why, h) + self.by
            prob = np.exp(y - np.max(y))
            prob /= np.sum(prob)
            ix = np.random.choice(range(self.output_size), p=prob.ravel())
            x = np.zeros((self.input_size, 1))
            x[ix] = 1
            ixes.append(ix)
        return ixes


# --------------------------------------
# 数据预处理
# --------------------------------------
def prepare_data(text):
    chars = list(set(text))
    char_to_idx = {ch: i for i, ch in enumerate(chars)}
    idx_to_char = {i: ch for i, ch in enumerate(chars)}
    return char_to_idx, idx_to_char


# 示例：从文件加载或直接提供文本
text = """
To be, or not to be: that is the question:
Whether 'tis nobler in the mind to suffer
The slings and arrows of outrageous fortune,
Or to take arms against a sea of troubles,
And by opposing end them?
"""

char_to_idx, idx_to_char = prepare_data(text)
vocab_size = len(char_to_idx)

# 设置超参数
hidden_size = 100
seq_length = 25
learning_rate = 1e-2
num_epochs = 1000

# 初始化模型
rnn = RNN(vocab_size, hidden_size, vocab_size)

# 开始训练
losses = []
ptr = 0
h_prev = np.zeros((hidden_size, 1))

for epoch in range(num_epochs):
    if ptr + seq_length + 1 >= len(text):
        ptr = 0
        h_prev = np.zeros((hidden_size, 1))  # 重置隐藏状态

    inputs = [char_to_idx[ch] for ch in text[ptr:ptr+seq_length]]
    targets = [char_to_idx[ch] for ch in text[ptr+1:ptr+seq_length+1]]

    # 前向传播
    outputs, hidden_states = rnn.forward(inputs, h_prev)

    # 计算损失
    loss, probs = rnn.loss(outputs, targets)
    losses.append(loss)

    # 反向传播
    dWxh, dWhh, dWhy, dbh, dby, dh_next = rnn.backward(inputs, targets, hidden_states, probs, h_prev)

    # 更新参数
    rnn.update(dWxh, dWhh, dWhy, dbh, dby, learning_rate)

    # 更新隐藏状态
    h_prev = dh_next

    # 每隔一定迭代打印损失和生成文本
    if epoch % 100 == 0:
        print(f"Epoch {epoch}, Loss: {loss:.4f}")
        sample_ix = rnn.sample(inputs[0], 200)
        txt = ''.join(idx_to_char[ix] for ix in sample_ix)
        print("---- Sample Text ----")
        print(txt)
        print("---------------------")

    ptr += seq_length