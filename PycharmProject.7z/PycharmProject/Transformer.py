import numpy as np
import math
from collections import Counter


# --------------------------------------
# 工具函数
# --------------------------------------
def softmax(x, axis=-1):
    x = x - np.max(x, axis=axis, keepdims=True)
    return np.exp(x) / np.sum(np.exp(x), axis=axis, keepdims=True)


def one_hot_encode(indices, vocab_size):
    one_hot = np.zeros((len(indices), vocab_size))
    one_hot[np.arange(len(indices)), indices] = 1
    return one_hot


# --------------------------------------
# 位置编码（Positional Encoding）
# --------------------------------------
def positional_encoding(length, depth):
    depth = depth / 2
    positions = np.arange(length)[:, np.newaxis]     # (length, 1)
    depths = np.arange(depth)[np.newaxis, :]/depth   # (1, depth)
    angle_rates = 1 / (10000**depths)
    angle_rads = positions * angle_rates  # (length, depth)

    pos_encoding = np.concatenate(
        [np.sin(angle_rads), np.cos(angle_rads)],
        axis=-1)
    return pos_encoding


# --------------------------------------
# 自注意力层（Self-Attention）
# --------------------------------------
class SelfAttention:
    def __init__(self, embed_dim, head_size):
        self.head_size = head_size
        self.Wq = np.random.randn(embed_dim, head_size) * 0.01
        self.Wk = np.random.randn(embed_dim, head_size) * 0.01
        self.Wv = np.random.randn(embed_dim, head_size) * 0.01

    def forward(self, x):
        self.x = x
        q = x @ self.Wq
        k = x @ self.Wk
        v = x @ self.Wv

        scores = q @ k.T / np.sqrt(self.head_size)
        self.att_weights = softmax(scores, axis=-1)

        out = self.att_weights @ v
        return out

    def backward(self, dout):
        q = self.x @ self.Wq
        k = self.x @ self.Wk
        v = self.x @ self.Wv

        dq = dout @ self.Wq.T
        dk = dout @ self.Wk.T
        dv = dout @ self.Wv.T

        dWq = self.x.T @ dq
        dWk = self.x.T @ dk
        dWv = self.x.T @ dv

        self.Wq -= 0.01 * dWq
        self.Wk -= 0.01 * dWk
        self.Wv -= 0.01 * dWv

        return dout @ (self.Wq + self.Wk + self.Wv).T


# --------------------------------------
# 多头注意力（Multi-head Attention）
# --------------------------------------
class MultiHeadAttention:
    def __init__(self, embed_dim, num_heads):
        self.head_size = embed_dim // num_heads
        self.heads = [SelfAttention(embed_dim, self.head_size) for _ in range(num_heads)]
        self.Wo = np.random.randn(embed_dim, embed_dim) * 0.01

    def forward(self, x):
        out = np.concatenate([head.forward(x) for head in self.heads], axis=-1)
        return out @ self.Wo

    def backward(self, dout):
        # 简化反向传播
        self.Wo -= 0.01 * self.heads[0].x.T @ dout
        return dout


# --------------------------------------
# 前馈网络（FeedForward）
# --------------------------------------
class FeedForward:
    def __init__(self, embed_dim, hidden_dim):
        self.W1 = np.random.randn(embed_dim, hidden_dim) * 0.01
        self.b1 = np.zeros(hidden_dim)
        self.W2 = np.random.randn(hidden_dim, embed_dim) * 0.01
        self.b2 = np.zeros(embed_dim)

    def forward(self, x):
        self.x = x
        x = np.maximum(0, x @ self.W1 + self.b1)
        return x @ self.W2 + self.b2

    def backward(self, dout):
        # 简化实现
        self.W2 -= 0.01 * self.x.T @ dout
        return dout


# --------------------------------------
# 编码器层（Encoder Layer）
# --------------------------------------
class EncoderLayer:
    def __init__(self, embed_dim, num_heads, hidden_dim):
        self.attn = MultiHeadAttention(embed_dim, num_heads)
        self.ffn = FeedForward(embed_dim, hidden_dim)
        self.norm1 = np.ones(embed_dim)
        self.norm2 = np.ones(embed_dim)

    def forward(self, x):
        x = x + self.attn.forward(x)
        x = (x - np.mean(x, axis=0)) / (np.std(x, axis=0) + 1e-6)
        x = x + self.ffn.forward(x)
        x = (x - np.mean(x, axis=0)) / (np.std(x, axis=0) + 1e-6)
        return x


# --------------------------------------
# 解码器层（Decoder Layer）
# --------------------------------------
class DecoderLayer:
    def __init__(self, embed_dim, num_heads, hidden_dim):
        self.masked_attn = MultiHeadAttention(embed_dim, num_heads)
        self.encoder_attn = MultiHeadAttention(embed_dim, num_heads)
        self.ffn = FeedForward(embed_dim, hidden_dim)

    def forward(self, x, encoder_output):
        x = x + self.masked_attn.forward(x)
        x = (x - np.mean(x, axis=0)) / (np.std(x, axis=0) + 1e-6)
        x = x + self.encoder_attn.forward(encoder_output)
        x = (x - np.mean(x, axis=0)) / (np.std(x, axis=0) + 1e-6)
        x = x + self.ffn.forward(x)
        x = (x - np.mean(x, axis=0)) / (np.std(x, axis=0) + 1e-6)
        return x


# --------------------------------------
# Transformer 模型
# --------------------------------------
class Transformer:
    def __init__(self, input_dim, output_dim, embed_dim=64, num_heads=4, hidden_dim=128, num_layers=2):
        self.embed_dim = embed_dim
        self.input_dim = input_dim
        self.output_dim = output_dim

        # Embedding + Positional Encoding
        self.token_emb = np.random.randn(input_dim, embed_dim) * 0.01
        self.pos_emb = np.random.randn(100, embed_dim) * 0.01

        # Encoder
        self.encoder_layers = [EncoderLayer(embed_dim, num_heads, hidden_dim) for _ in range(num_layers)]

        # Decoder
        self.decoder_layers = [DecoderLayer(embed_dim, num_heads, hidden_dim) for _ in range(num_layers)]

        # Output
        self.final_linear = np.random.randn(embed_dim, output_dim) * 0.01

    def forward(self, src, tgt):
        batch_size, src_len = src.shape
        _, tgt_len = tgt.shape

        # Embedding + Positional Encoding
        src_emb = self.token_emb[src] + self.pos_emb[:src_len]
        tgt_emb = self.token_emb[tgt] + self.pos_emb[:tgt_len]

        # Encoder
        enc_out = src_emb
        for layer in self.encoder_layers:
            enc_out = layer.forward(enc_out)

        # Decoder
        dec_out = tgt_emb
        for layer in self.decoder_layers:
            dec_out = layer.forward(dec_out, enc_out)

        # Final output
        logits = dec_out @ self.final_linear
        return logits

    def loss(self, logits, targets):
        logits = logits.reshape(-1, self.output_dim)
        probs = softmax(logits, axis=1)
        loss = -np.mean(np.log(probs[np.arange(len(targets)), targets.flatten()] + 1e-15))
        return loss, probs

    def predict(self, src, max_len=50):
        batch_size = src.shape[0]
        src_emb = self.token_emb[src] + self.pos_emb[:src.shape[1]]
        enc_out = src_emb
        for layer in self.encoder_layers:
            enc_out = layer.forward(enc_out)

        # Start with <start> token
        tgt = np.zeros((batch_size, 1), dtype=int)
        outputs = []

        for _ in range(max_len):
            tgt_emb = self.token_emb[tgt] + self.pos_emb[:tgt.shape[1]]
            dec_out = tgt_emb
            for layer in self.decoder_layers:
                dec_out = layer.forward(dec_out, enc_out)
            logits = dec_out @ self.final_linear
            next_token = np.argmax(logits[:, -1, :], axis=1)
            outputs.append(next_token)
            tgt = np.concatenate([tgt, next_token[:, None]], axis=1)

        return np.array(outputs).T


# --------------------------------------
# 数据预处理
# --------------------------------------
text = """
To be, or not to be: that is the question:
Whether 'tis nobler in the mind to suffer
The slings and arrows of outrageous fortune,
Or to take arms against a sea of troubles,
And by opposing end them?
"""

chars = sorted(list(set(text)))
char_to_idx = {ch: i for i, ch in enumerate(chars)}
idx_to_char = {i: ch for i, ch in enumerate(chars)}
vocab_size = len(chars)

# 超参数
embed_dim = 64
num_heads = 4
num_layers = 2
hidden_dim = 128
seq_length = 15
batch_size = 1
learning_rate = 1e-3

# 构建输入输出序列
def get_batch():
    start = np.random.randint(0, len(text) - seq_length - 1)
    src = [char_to_idx[c] for c in text[start:start+seq_length]]
    tgt = [char_to_idx[c] for c in text[start+1:start+seq_length+1]]
    return np.array([src]), np.array([tgt])

# 初始化模型
transformer = Transformer(vocab_size, vocab_size, embed_dim, num_heads, hidden_dim, num_layers)

# 开始训练
for epoch in range(1000):
    src, tgt = get_batch()
    logits = transformer.forward(src, tgt)
    loss, probs = transformer.loss(logits, tgt)

    # 简单梯度下降（简化版）
    if epoch % 100 == 0:
        print(f"Epoch {epoch}, Loss: {loss:.4f}")
        pred_seq = transformer.predict(src)
        print("Input:  ", ''.join(idx_to_char[i] for i in src[0]))
        print("Predict:", ''.join(idx_to_char[i] for i in pred_seq[0]))
        print("Target: ", ''.join(idx_to_char[i] for i in tgt[0]))
        print("-" * 40)