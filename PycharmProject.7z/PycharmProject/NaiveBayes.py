import numpy as np
from collections import defaultdict


# 高斯朴素贝叶斯
class GaussianNB:
    def __init__(self):
        self.class_priors = None  # 先验概率 P(y)
        self.class_stats = None  # 每个类的特征统计量（均值、方差）

    def fit(self, X, y):
        n_samples, n_features = X.shape
        self.classes = np.unique(y)
        n_classes = len(self.classes)

        # 计算先验概率 P(y)
        self.class_priors = np.zeros(n_classes)
        self.class_stats = defaultdict(list)

        for i, c in enumerate(self.classes):
            X_c = X[y == c]
            self.class_priors[i] = X_c.shape[0] / n_samples

            # 计算每个特征的均值和方差
            class_mean = np.mean(X_c, axis=0)
            class_var = np.var(X_c, axis=0)
            self.class_stats[c] = (class_mean, class_var)

    def _gaussian_pdf(self, x, mean, var):
        """高斯概率密度函数"""
        eps = 1e-4  # 防止方差为0
        coeff = 1.0 / np.sqrt(2 * np.pi * var + eps)
        exponent = np.exp(-(x - mean) ** 2 / (2 * var + eps))
        return coeff * exponent

    def predict(self, X):
        """预测类别"""
        posteriors = []

        for c in self.classes:
            prior = np.log(self.class_priors[np.where(self.classes == c)[0][0]])
            mean, var = self.class_stats[c]

            # 计算似然 P(x|y) 的log（独立特征相乘转换为log相加）
            likelihood = np.sum(np.log(self._gaussian_pdf(X, mean, var)), axis=1)
            posterior = prior + likelihood
            posteriors.append(posterior)

        # 选择后验概率最大的类别
        return self.classes[np.argmax(np.array(posteriors), axis=0)]


# 示例使用
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score

iris = load_iris()
X, y = iris.data, iris.target
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

model = GaussianNB()
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
print(f"准确率: {accuracy_score(y_test, y_pred):.2f}")