import numpy as np
import matplotlib.pyplot as plt

def euclidean_distance(a, b):
    """计算两个向量之间的欧几里得距离"""
    return np.linalg.norm(a - b)

def kmeans(X, k, max_iters=100, random_seed=None):
    """
    K-means 聚类算法实现
    参数：
        X: 数据集，形状为 (n_samples, n_features)
        k: 聚类数量
        max_iters: 最大迭代次数
        random_seed: 随机种子
    返回：
        labels: 每个样本的类别标签
        centroids: 最终的聚类中心
    """
    if random_seed is not None:
        np.random.seed(random_seed)

    # Step 1: 随机选择初始质心
    n_samples, n_features = X.shape
    centroids = X[np.random.choice(n_samples, k, replace=False)]

    # 初始化标签
    labels = np.zeros(n_samples)

    for _ in range(max_iters):
        # Step 2: 分配每个样本到最近的质心
        for i, sample in enumerate(X):
            distances = [euclidean_distance(sample, centroid) for centroid in centroids]
            labels[i] = np.argmin(distances)

        # Step 3: 更新质心为每个簇的均值
        new_centroids = np.array([X[labels == j].mean(axis=0) for j in range(k)])

        # 判断是否收敛
        if np.allclose(centroids, new_centroids):
            break

        centroids = new_centroids

    return labels, centroids

# 示例：生成随机数据并进行聚类
if __name__ == "__main__":
    from sklearn.datasets import make_blobs

    # 生成随机数据
    n_samples = 300
    n_features = 2
    k = 3
    X, y_true = make_blobs(n_samples=n_samples, centers=k, random_state=42)

    # 使用 K-means 聚类
    labels, centroids = kmeans(X, k, random_seed=42)

    # 可视化结果
    plt.figure(figsize=(8, 6))
    colors = ['r', 'g', 'b', 'y', 'c', 'm']

    for i in range(k):
        plt.scatter(X[labels == i, 0], X[labels == i, 1], c=colors[i], label=f'Cluster {i+1}')

    plt.scatter(centroids[:, 0], centroids[:, 1], s=300, c='black', marker='X', label='Centroids')
    plt.title("K-means Clustering")
    plt.legend()
    plt.show()