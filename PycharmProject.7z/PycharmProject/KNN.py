import numpy as np
from collections import Counter
from sklearn.preprocessing import StandardScaler


class KNN:
    def __init__(self, k=5, task='classification', distance='euclidean'):
        """
        参数:
        - k: 邻居数量
        - task: 'classification' 或 'regression'
        - distance: 'euclidean'(欧氏距离), 'manhattan'(曼哈顿距离)
        """
        self.k = k
        self.task = task
        self.distance = distance
        self.scaler = None  # 用于特征标准化

    def _calc_distance(self, x1, x2):
        """计算两个样本之间的距离"""
        if self.distance == 'euclidean':
            return np.sqrt(np.sum((x1 - x2) ** 2))
        elif self.distance == 'manhattan':
            return np.sum(np.abs(x1 - x2))
        else:
            raise ValueError("Unsupported distance metric")

    def fit(self, X, y):
        """训练KNN模型（实际只是存储数据）"""
        # 特征标准化
        self.scaler = StandardScaler()
        self.X_train = self.scaler.fit_transform(X)
        self.y_train = np.array(y)

    def predict(self, X):
        """预测新样本"""
        X = self.scaler.transform(X)
        y_pred = []

        for x in X:
            # 计算与所有训练样本的距离
            distances = [self._calc_distance(x, x_train) for x_train in self.X_train]

            # 获取最近的k个样本的索引
            k_indices = np.argsort(distances)[:self.k]
            k_nearest_labels = self.y_train[k_indices]

            # 根据任务类型进行预测
            if self.task == 'classification':
                # 多数投票
                most_common = Counter(k_nearest_labels).most_common(1)
                y_pred.append(most_common[0][0])
            else:  # regression
                # 取平均值
                y_pred.append(np.mean(k_nearest_labels))

        return np.array(y_pred)

    def predict_proba(self, X):
        """返回分类概率（仅分类任务可用）"""
        if self.task != 'classification':
            raise ValueError("Probability prediction only available for classification")

        X = self.scaler.transform(X)
        probas = []

        for x in X:
            distances = [self._calc_distance(x, x_train) for x_train in self.X_train]
            k_indices = np.argsort(distances)[:self.k]
            k_nearest_labels = self.y_train[k_indices]

            # 计算各类别比例
            counter = Counter(k_nearest_labels)
            proba = [counter.get(label, 0) / self.k for label in np.unique(self.y_train)]
            probas.append(proba)

        return np.array(probas)


from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score

# 加载数据
iris = load_iris()
X, y = iris.data, iris.target
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# 训练KNN分类器
knn_classifier = KNN(k=3, task='classification')
knn_classifier.fit(X_train, y_train)

# 预测
y_pred = knn_classifier.predict(X_test)
print(f"预测结果: {y_pred}")
print(f"真实标签: {y_test}")
print(f"准确率: {accuracy_score(y_test, y_pred):.2f}")

# 预测概率
print("类别概率:")
print(knn_classifier.predict_proba(X_test[:3]))  # 查看前3个样本的概率