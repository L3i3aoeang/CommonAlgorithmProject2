import numpy as np
from sklearn.datasets import make_blobs
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score


class MLP:
    def __init__(self, input_dim, hidden_dims, output_dim, lr=0.01):
        """
        多层感知机分类器
        :param input_dim: 输入特征维度
        :param hidden_dims: 隐藏层维度列表，例如 [64, 32]
        :param output_dim: 输出类别数
        :param lr: 学习率
        """
        self.lr = lr
        self.parameters = {}

        # 初始化参数
        dims = [input_dim] + hidden_dims + [output_dim]
        for i in range(len(dims) - 1):
            self.parameters[f'W{i}'] = np.random.randn(dims[i], dims[i+1]) * 0.01
            self.parameters[f'b{i}'] = np.zeros((1, dims[i+1]))

    def _relu(self, x):
        return np.maximum(0, x)

    def _softmax(self, x):
        exps = np.exp(x - np.max(x, axis=1, keepdims=True))
        return exps / np.sum(exps, axis=1, keepdims=True)

    def forward(self, X):
        cache = {'A0': X}
        L = len(self.parameters) // 2

        # 前向传播
        for i in range(L - 1):
            Z = cache[f'A{i}'] @ self.parameters[f'W{i}'] + self.parameters[f'b{i}']
            cache[f'Z{i+1}'] = Z
            cache[f'A{i+1}'] = self._relu(Z)

        # 输出层（不加激活函数，后面接 softmax）
        ZL = cache[f'A{L-1}'] @ self.parameters[f'W{L-1}'] + self.parameters[f'b{L-1}']
        cache[f'Z{L}'] = ZL
        cache[f'A{L}'] = self._softmax(ZL)

        return cache

    def compute_loss(self, y_true, probs):
        """计算交叉熵损失"""
        m = y_true.shape[0]
        log_probs = -np.log(probs[range(m), y_true] + 1e-15)
        loss = np.sum(log_probs) / m
        return loss

    def backward(self, cache, y_true):
        """反向传播"""
        grads = {}
        m = y_true.shape[0]
        L = len(self.parameters) // 2

        # 输出层误差
        dZ = cache[f'A{L}']
        dZ[range(m), y_true] -= 1
        dZ /= m

        grads[f'dW{L-1}'] = cache[f'A{L-1}'].T @ dZ
        grads[f'db{L-1}'] = np.sum(dZ, axis=0, keepdims=True)

        dA_prev = dZ @ self.parameters[f'W{L-1}'].T

        # 隐藏层反向传播
        for i in reversed(range(L - 1)):
            dZ = dA_prev * (cache[f'Z{i+1}'] > 0)
            grads[f'dW{i}'] = cache[f'A{i}'].T @ dZ
            grads[f'db{i}'] = np.sum(dZ, axis=0, keepdims=True)
            if i > 0:
                dA_prev = dZ @ self.parameters[f'W{i}'].T

        return grads

    def update_parameters(self, grads):
        """更新参数"""
        for key in self.parameters:
            self.parameters[key] -= self.lr * grads['d' + key[1:]]

    def fit(self, X_train, y_train, epochs=100, batch_size=32, verbose=True):
        """训练模型"""
        losses = []
        n_samples = X_train.shape[0]
        for epoch in range(epochs):
            indices = np.random.permutation(n_samples)
            for i in range(0, n_samples, batch_size):
                batch_indices = indices[i:i+batch_size]
                X_batch, y_batch = X_train[batch_indices], y_batch = y_train[batch_indices]

                # 前向传播
                cache = self.forward(X_batch)

                # 反向传播
                grads = self.backward(cache, y_batch)
                self.update_parameters(grads)

            # 计算损失
            cache = self.forward(X_train)
            loss = self.compute_loss(y_train, cache[f'A{L}'])
            losses.append(loss)

            if verbose and (epoch % 10 == 0 or epoch == epochs - 1):
                y_pred = np.argmax(cache[f'A{L}'], axis=1)
                acc = accuracy_score(y_train, y_pred)
                print(f"Epoch {epoch}, Loss: {loss:.4f}, Accuracy: {acc:.4f}")

        return losses

    def predict(self, X):
        """预测类别"""
        cache = self.forward(X)
        L = len(self.parameters) // 2
        return np.argmax(cache[f'A{L}'], axis=1)


# 示例：使用 MLP 对生成数据进行分类
if __name__ == "__main__":
    # 生成数据
    X, y = make_blobs(n_samples=500, centers=3, random_state=42)
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    # 初始化并训练模型
    mlp = MLP(input_dim=2, hidden_dims=[16, 8], output_dim=3, lr=0.1)
    loss_history = mlp.fit(X_train, y_train, epochs=200, batch_size=16)

    # 测试集评估
    y_pred = mlp.predict(X_test)
    acc = accuracy_score(y_test, y_pred)
    print(f"Test Accuracy: {acc:.4f}")