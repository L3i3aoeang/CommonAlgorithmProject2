import numpy as np
from collections import Counter
import matplotlib.pyplot as plt

class DecisionTree:
    def __init__(self, max_depth=None, min_samples_split=2):
        self.max_depth = max_depth  # 最大深度
        self.min_samples_split = min_samples_split  # 分裂最小样本数
        self.tree = None  # 树结构

    def _entropy(self, y):
        """计算熵"""
        counts = Counter(y)
        probs = [count / len(y) for count in counts.values()]
        return -sum(p * np.log2(p) for p in probs)

    def _information_gain(self, X_col, y, split_threshold):
        """计算信息增益"""
        # 分割后的子集
        left_idx = X_col <= split_threshold
        right_idx = X_col > split_threshold
        y_left, y_right = y[left_idx], y[right_idx]

        if len(y_left) == 0 or len(y_right) == 0:
            return 0

        # 父节点熵 - 加权子节点熵
        parent_entropy = self._entropy(y)
        child_entropy = (len(y_left) / len(y)) * self._entropy(y_left) + \
                        (len(y_right) / len(y)) * self._entropy(y_right)
        return parent_entropy - child_entropy

    def _best_split(self, X, y):
        """寻找最佳分割点和特征"""
        best_gain = -1
        best_feature, best_threshold = None, None

        for feature_idx in range(X.shape[1]):
            X_col = X[:, feature_idx]
            thresholds = np.unique(X_col)

            for threshold in thresholds:
                gain = self._information_gain(X_col, y, threshold)
                if gain > best_gain:
                    best_gain = gain
                    best_feature = feature_idx
                    best_threshold = threshold

        return best_feature, best_threshold

    def _build_tree(self, X, y, depth=0):
        """递归构建决策树"""
        n_samples, n_features = X.shape

        # 终止条件
        if (depth == self.max_depth) or \
                (n_samples < self.min_samples_split) or \
                (len(np.unique(y)) == 1):
            return Counter(y).most_common(1)[0][0]  # 返回多数类

        # 找到最佳分割
        feature_idx, threshold = self._best_split(X, y)

        # 递归构建子树
        left_idx = X[:, feature_idx] <= threshold
        right_idx = X[:, feature_idx] > threshold

        left_subtree = self._build_tree(X[left_idx], y[left_idx], depth + 1)
        right_subtree = self._build_tree(X[right_idx], y[right_idx], depth + 1)

        return (feature_idx, threshold, left_subtree, right_subtree)

    def fit(self, X, y):
        """训练入口"""
        self.tree = self._build_tree(np.array(X), np.array(y))

    def _predict_sample(self, x, node):
        """单样本预测"""
        if isinstance(node, (int, np.integer)):  # 叶节点
            return node

        feature_idx, threshold, left, right = node
        if x[feature_idx] <= threshold:
            return self._predict_sample(x, left)
        else:
            return self._predict_sample(x, right)

    def predict(self, X):
        """批量预测"""
        return [self._predict_sample(x, self.tree) for x in np.array(X)]


from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score

# 加载数据
iris = load_iris()
X, y = iris.data[:, :2], iris.target  # 只用前两个特征简化演示
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# 训练模型
model = DecisionTree(max_depth=3)
model.fit(X_train, y_train)

# 评估
y_pred = model.predict(X_test)
print(f"测试集准确率: {accuracy_score(y_test, y_pred):.2f}")


# 可视化决策边界
def plot_decision_boundary(X, y, model):
    x_min, x_max = X[:, 0].min() - 1, X[:, 0].max() + 1
    y_min, y_max = X[:, 1].min() - 1, X[:, 1].max() + 1
    xx, yy = np.meshgrid(np.linspace(x_min, x_max, 100),
                         np.linspace(y_min, y_max, 100))

    Z = model.predict(np.c_[xx.ravel(), yy.ravel()])
    Z = np.array(Z).reshape(xx.shape)

    plt.contourf(xx, yy, Z, alpha=0.4)
    plt.scatter(X[:, 0], X[:, 1], c=y, s=20, edgecolor='k')
    plt.xlabel("Sepal Length")
    plt.ylabel("Sepal Width")
    plt.title("Decision Tree Classification")


plot_decision_boundary(X, y, model)
plt.show()