import numpy as np
import matplotlib.pyplot as plt
from sklearn.datasets import make_blobs


class PCA:
    def __init__(self, n_components):
        self.n_components = n_components
        self.components = None
        self.mean = None

    def fit(self, X):
        """
        训练 PCA 模型：计算协方差矩阵的特征向量
        参数：
            X: shape (n_samples, n_features)
        """
        # 1. 零均值化
        self.mean = np.mean(X, axis=0)
        X_centered = X - self.mean

        # 2. 计算协方差矩阵
        cov_matrix = np.cov(X_centered, rowvar=False)

        # 3. 特征值分解
        eigen_values, eigen_vectors = np.linalg.eigh(cov_matrix)

        # 4. 从大到小排序特征向量
        idx = np.argsort(eigen_values)[::-1]
        eigen_vectors_sorted = eigen_vectors[:, idx]

        # 5. 选择前 k 个特征向量
        self.components = eigen_vectors_sorted[:, :self.n_components]

    def transform(self, X):
        """
        将数据投影到低维空间
        返回：降维后的数据
        """
        X_centered = X - self.mean
        return np.dot(X_centered, self.components)

    def inverse_transform(self, X_pca):
        """
        将降维后的数据还原回原始空间
        """
        return np.dot(X_pca, self.components.T) + self.mean


# 示例：使用 PCA 进行二维数据降维可视化
if __name__ == "__main__":
    # 生成随机数据
    X, y = make_blobs(n_samples=200, centers=3, random_state=42)

    # 初始化 PCA（保留1个主成分）
    pca = PCA(n_components=1)
    pca.fit(X)

    # 降维
    X_pca = pca.transform(X)

    # 还原数据（用于可视化对比）
    X_reconstructed = pca.inverse_transform(X_pca)

    # 可视化原始数据和降维后映射回的数据
    plt.figure(figsize=(8, 6))
    plt.scatter(X[:, 0], X[:, 1], label='Original Data', alpha=0.7)
    plt.scatter(X_reconstructed[:, 0], X_reconstructed[:, 1], c='r', label='Reconstructed Data', alpha=0.7)

    # 绘制主成分方向
    components = pca.components
    mean = pca.mean
    for length, vector in zip([2, 1], components.T):
        v = vector * 3 * length
        plt.arrow(mean[0], mean[1], v[0], v[1], head_width=0.1, linewidth=2, color='k', zorder=5)

    plt.axis('equal')
    plt.title("PCA Visualization")
    plt.legend()
    plt.xlabel("Feature 1")
    plt.ylabel("Feature 2")
    plt.show()

    # 输出降维后的数据形状
    print("降维后数据形状:", X_pca.shape)