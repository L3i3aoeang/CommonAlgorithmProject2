import numpy as np
import matplotlib.pyplot as plt
from scipy.cluster.hierarchy import dendrogram, linkage
from sklearn.datasets import make_blobs


def euclidean_distance(a, b):
    """计算两个向量之间的欧几里得距离"""
    return np.linalg.norm(a - b)


def pairwise_distances(X):
    """计算所有样本之间的成对距离"""
    n_samples = X.shape[0]
    dist_matrix = np.zeros((n_samples, n_samples))
    for i in range(n_samples):
        for j in range(i + 1, n_samples):
            dist = euclidean_distance(X[i], X[j])
            dist_matrix[i, j] = dist
            dist_matrix[j, i] = dist
    return dist_matrix


def hierarchical_clustering(X, method='single'):
    """
    构建层次聚类的连接矩阵（linkage matrix）
    支持 single linkage
    返回：linkage_matrix 用于绘制 dendrogram
    """
    n_samples = X.shape[0]
    clusters = [[i] for i in range(n_samples)]  # 初始：每个样本是一个簇
    linkage_matrix = []
    current_label = n_samples  # 从 n_samples 开始为新簇编号

    # 构建初始距离矩阵
    dist_matrix = pairwise_distances(X)

    while len(clusters) > 1:
        # 找最小距离的两个簇
        min_dist = np.inf
        c1, c2 = -1, -1

        for i in range(len(clusters)):
            for j in range(i + 1, len(clusters)):
                # 计算簇间最小距离（Single Linkage）
                idx_i = clusters[i]
                idx_j = clusters[j]
                distances = dist_matrix[np.ix_(idx_i, idx_j)]
                current_min = distances.min()

                if current_min < min_dist:
                    min_dist = current_min
                    c1, c2 = i, j

        # 合并簇
        merged_cluster = clusters[c1] + clusters[c2]
        linkage_matrix.append([X[clusters[c1]].mean(axis=0), X[clusters[c2]].mean(axis=0),
                               min_dist, len(merged_cluster)])
        # 替换簇
        clusters.append(merged_cluster)
        del clusters[max(c1, c2)]
        del clusters[min(c1, c2)]

    # 生成用于 dendrogram 的 linkage matrix
    linkage_matrix = np.array(linkage_matrix)
    return linkage_matrix


def plot_dendrogram(linkage_matrix):
    """绘制树状图"""
    plt.figure(figsize=(10, 6))
    dendrogram(linkage_matrix)
    plt.title("Dendrogram")
    plt.xlabel("Data Points")
    plt.ylabel("Distance")
    plt.show()


def cut_tree(linkage_matrix, n_clusters):
    """
    从 linkage matrix 中提取指定数量的簇标签
    """
    n_samples = linkage_matrix.shape[0] + 1
    label = np.arange(n_samples)
    cluster_labels = np.arange(n_samples)

    i = n_samples
    for row in linkage_matrix:
        coor1 = row[0]
        coor2 = row[1]
        indices = (label == coor1) | (label == coor2)
        cluster_labels[indices] = i
        label[indices] = i
        i += 1

    # 重新编号为 0 到 n_clusters-1
    _, final_labels = np.unique(cluster_labels, return_inverse=True)
    return final_labels[:n_samples]


# 示例代码
if __name__ == "__main__":
    # 生成随机数据
    X, y_true = make_blobs(n_samples=30, centers=4, random_state=42)

    # 构建链接矩阵（使用自定义实现）
    linkage_matrix = hierarchical_clustering(X, method='single')

    # 绘制树状图
    plot_dendrogram(linkage_matrix)

    # 从树状图中切分出 3 个簇
    labels = cut_tree(linkage_matrix, n_clusters=4)

    # 可视化聚类结果
    plt.figure(figsize=(8, 6))
    plt.scatter(X[:, 0], X[:, 1], c=labels, cmap='tab10', s=100)
    plt.title("Hierarchical Clustering Result")
    plt.xlabel("Feature 1")
    plt.ylabel("Feature 2")
    plt.show()